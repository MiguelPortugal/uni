import java.until*;
class pot {
  public static void main (String[] args){
    public int pot
    if ( pot ==6){
      Sistem.out.println(" Million");
    }else if (pot == 9){
      Sistem.out.println("Billion");
    }else if ( pot == 12){
      Sistem.out.println("Trillion");
    
        
        
      
    
     
    
  
    
  