import java.util.*;
class Ex12pag294{
 public int n = x ;
 Sistem.out.printl("Indique um numero" x);
 
  boolean div 4 = n%4 ==0 ;
  boolean div 100 = n%100 ==0;
  boolean div 400 = n%400==0;
  boolean isLapYear = (div4 && !div100)|| (div4 && div100 && div 400)
    if(isLapYear){
     s.o.p("Lap Year");
  }else{
    s.o.p ( "Not Lap Year");
  }