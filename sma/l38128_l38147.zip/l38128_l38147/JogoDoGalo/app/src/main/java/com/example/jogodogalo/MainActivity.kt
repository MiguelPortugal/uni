package com.example.jogodogalo

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




        findViewById<Button>(R.id.b1).setOnClickListener{
            startgame()
        }

        findViewById<Button>(R.id.b2).setOnClickListener{
            startoption()
        }

        findViewById<Button>(R.id.b3).setOnClickListener{
            exitGame()
        }



    }



    private fun startgame(){
        val intent = Intent (this, GameActivity::class.java)
        startActivity(intent)
    }


    private fun startoption(){
        val intent = Intent (this, OptionActivity::class.java)
        startActivity(intent)
    }

    private fun exitGame(){
          finish()
          System.exit(0);
        }
}