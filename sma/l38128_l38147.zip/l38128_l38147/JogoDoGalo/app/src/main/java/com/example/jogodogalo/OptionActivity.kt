package com.example.jogodogalo

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class OptionActivity : AppCompatActivity() {

    private var mediaplayer:MediaPlayer?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_option)

        mediaplayer = MediaPlayer.create(this, R.raw.music )
        mediaplayer?.start()



        findViewById<ImageButton>(R.id.play_b).setOnClickListener{
            mediaplayer?.start()
        }

        findViewById<ImageButton>(R.id.pause_b).setOnClickListener{
            mediaplayer?.pause()
        }





    }




}
